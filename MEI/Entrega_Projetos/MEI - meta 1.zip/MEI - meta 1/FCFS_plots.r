  require(MASS)
    
  fcfs <- read.csv("fcfs.txt")
  rr <- read.csv("rr.txt")
  srtf <- read.csv("srtf.txt")
  sjf <- read.csv("sjf.txt")
  workload <- read.csv("workload.txt")
  
  attach(fcfs)
  
  # histograms
  
  oldpar <- par(mfrow = c(1, 1))
  
  hist(fcfs$tat, 
       main = "Turnaround Time Histogram", 
       xlab = "Time",  
       col = 'skyblue3',
       prob = TRUE,
       breaks = 6)
  
  lines(density(fcfs$tat), 
        col="red",
        lty="dotted",
        lwd=3) # add a density estimate with defaults
  
  hist(fcfs$ready_wait_time, 
       main = "Wait Time Histogram", 
       xlab = "Time",  
       col = 'skyblue3',
       prob = TRUE,
       breaks = 6)
  
  lines(density(fcfs$ready_wait_time), 
        col="red",
        lty="dotted",
        lwd=3) # add a density estimate with defaults
  
  
  hist(fcfs$cpu_bursts_time, 
       main = "CPU Bursts Histogram",
       prob = TRUE,
       col = 'skyblue3',
       xlab = "Time",
      )
  
  lines(density(fcfs$cpu_bursts_time), # density plot
        lwd = 2, # thickness of line
        col = "red", 
        lty = "dashed")
  
  # Relational Graphs
  
  pairs(cbind(fcfs$arrival_time,
              fcfs$cpu_bursts_time, 
              fcfs$tat, 
              fcfs$ready_wait_time), 
        labels = c("Arrival Time", "CPU Bursts", "Turnaround Time", "CPU Wait Time"),
        gap = 0, 
        panel = panel.smooth)
  
  library(plotly)
  
  # Initialize empty plot
  fig <- plot_ly(type = 'scatter')
  
  # Each task is a separate trace
  # Each trace is essentially a thick line plot
  # x-axis ticks are dates and handled automatically
  
  for(i in 1:(nrow(fcfs) - 1)){
    fig <- add_trace(fig,
                     x = c(srtf$arrival_time[i], srtf$arrival_time[i] + srtf$tat[i]),  # x0, x1
                     name = "ms",
                     y = c(i, i),  # y0, y1
                     mode = "lines",
                     line = list(color = fcfs$color[i], width = 2),
                     showlegend = F,
                     hoverinfo = "text",
                     
                     # Create custom hover text
                     
                     text = paste("Task: ", srtf$pid[i], "<br>",
                                  "Duration: ", srtf$tat[i], "days<br>"),
                     
                     evaluate = T  # needed to avoid lazy loading
    )
    
  }
  
  fig <- layout(fig,
                title = "Processes Gantt Chart",
                xaxis = list(showgrid = F, tickfont = list(color = "#333333"), title="ms"),
                
                yaxis = list(showgrid = F, tickfont = list(color = "#333333"),
                             tickmode = "array", tickvals = 1:nrow(fcfs), ticktext = unique(fcfs$pid),
                             domain = c(0, 0.9)), title = "Process") # Axis area color
  
  
  fig
  
  
