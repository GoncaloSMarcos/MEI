setwd('C:/Users/Asus/Desktop/MEI/MEI/assignment')

srtf.dat <- read.csv(file = "srtf.txt")

require(MASS)
attach(srtf.dat)

#histograms
hist(srtf.dat[,9], col = "grey", main = "Wait Time", ylab = "Frequency", freq = FALSE,xlab = "Time")
hist(tat, col = "grey", main = "Turn Around Time", ylab = "Frequency", freq = FALSE,xlab = "Time")
hist(bursts_time, col = "grey", main = "Bursts Time", ylab = "Frequency", freq = FALSE,xlab = "Time")

lines(density(bursts_time), lwd = 2)
box()


#summary
summary(srtf.dat)


#Scatter plot matrices
pairs(cbind(arrival_time, bursts_time, tat, ready_wait_time), gap = 0, panel = panel.smooth)

truehist(ready_wait_time, nbins = "FD", col = "skyblue3", main = "Wait Time", ylab = "Frequency", xlab = "Time")
lines(density(ready_wait_time), lwd = 2, col="red", lty = "dashed")
box()