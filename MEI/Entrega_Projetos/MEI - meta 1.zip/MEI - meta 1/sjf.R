setwd('C:/Users/Asus/Desktop/MEI/MEI/assignment')

sjf.dat <- read.csv(file = "sjf.txt")

#coluna do tempo de espera total
sjf.dat[,9] <- sjf.dat[,8] + sjf.dat[,7]
colnames(sjf.dat)[9] <- "wait"
sjf.dat[,10] <- sjf.dat[,6] - sjf.dat[,8]
sjf.dat[,11] <- (sjf.dat[,10] *100)/sjf.dat[,6]

#sumario
summary(sjf.dat)

#funcao para imprimir
np = cat(paste(sjf.dat[,1], collapse=","))

# Grouped Bar Plot - Wait Time
barplot(sjf.dat[,9], col=c("darkgreen"),ylab="Time", beside=TRUE, main = "Waiting Time", 
        names.arg = c(42,47,29,45,20,46,11,35,43,16,34,44,40,3,7,21,19,38,0,25,14,18,30,36,39,28,26,48,17,13,2,24,5,1,22,23,31,10,41,4,27,32,6,33,49,12,8,9,15,37))
box()

#Wait Time - ArrivalTime
barplot(sjf.dat[,9] - sjf.dat[,2], col=c("pink"),ylab="Time", beside=TRUE, main = "Waiting Time - Arrival Time", 
        names.arg = c(42,47,29,45,20,46,11,35,43,16,34,44,40,3,7,21,19,38,0,25,14,18,30,36,39,28,26,48,17,13,2,24,5,1,22,23,31,10,41,4,27,32,6,33,49,12,8,9,15,37))
box()


# Grouped Bar Plot
tat_waiting = cbind(c(sjf.dat[1,9], sjf.dat[1,6]), c(sjf.dat[2,9], sjf.dat[2,6]), c(sjf.dat[3,9], sjf.dat[3,6]), c(sjf.dat[4,9], sjf.dat[4,6]), c(sjf.dat[5,9], sjf.dat[5,6]), c(sjf.dat[6,9], sjf.dat[6,6]), c(sjf.dat[7,9], sjf.dat[7,6]), c(sjf.dat[8,9], sjf.dat[8,6]), c(sjf.dat[9,9], sjf.dat[9,6]), c(sjf.dat[10,9], sjf.dat[10,6]), c(sjf.dat[11,9], sjf.dat[11,6]), c(sjf.dat[12,9], sjf.dat[12,6]), c(sjf.dat[13,9], sjf.dat[13,6]), c(sjf.dat[14,9], sjf.dat[14,6]), c(sjf.dat[15,9], sjf.dat[15,6]), c(sjf.dat[16,9], sjf.dat[16,6]), c(sjf.dat[17,9], sjf.dat[17,6]), c(sjf.dat[18,9], sjf.dat[18,6]), c(sjf.dat[19,9], sjf.dat[19,6]), c(sjf.dat[20,9], sjf.dat[20,6]), c(sjf.dat[21,9], sjf.dat[21,6]), c(sjf.dat[22,9], sjf.dat[22,6]), c(sjf.dat[23,9], sjf.dat[23,6]), c(sjf.dat[24,9], sjf.dat[24,6]), c(sjf.dat[25,9], sjf.dat[25,6]), c(sjf.dat[26,9], sjf.dat[26,6]), c(sjf.dat[27,9], sjf.dat[27,6]), c(sjf.dat[28,9], sjf.dat[28,6]), c(sjf.dat[29,9], sjf.dat[29,6]), c(sjf.dat[30,9], sjf.dat[30,6]), c(sjf.dat[31,9], sjf.dat[31,6]), c(sjf.dat[32,9], sjf.dat[32,6]), c(sjf.dat[33,9], sjf.dat[33,6]), c(sjf.dat[34,9], sjf.dat[34,6]), c(sjf.dat[35,9], sjf.dat[35,6]), c(sjf.dat[36,9], sjf.dat[36,6]), c(sjf.dat[37,9], sjf.dat[37,6]), c(sjf.dat[38,9], sjf.dat[38,6]), c(sjf.dat[39,9], sjf.dat[39,6]), c(sjf.dat[40,9], sjf.dat[40,6]), c(sjf.dat[41,9], sjf.dat[41,6]), c(sjf.dat[42,9], sjf.dat[42,6]), c(sjf.dat[43,9], sjf.dat[43,6]), c(sjf.dat[44,9], sjf.dat[44,6]), c(sjf.dat[45,9], sjf.dat[45,6]), c(sjf.dat[46,9], sjf.dat[46,6]), c(sjf.dat[47,9], sjf.dat[47,6]), c(sjf.dat[48,9], sjf.dat[48,6]), c(sjf.dat[49,9], sjf.dat[49,6]), c(sjf.dat[50,9], sjf.dat[50,6]))

colnames(tat_waiting) <- c(42,47,29,45,20,46,11,35,43,16,34,44,40,3,7,21,19,38,0,25,14,18,30,36,39,28,26,48,17,13,2,24,5,1,22,23,31,10,41,4,27,32,6,33,49,12,8,9,15,37)
barplot(tat_waiting, col=c("darkblue","red"),ylab="Time", beside=TRUE, main = "Wait Time Vs TAT")
legend(x=5, y=2000,c("Wait Time", "Turnaround Time"), fill = c("darkblue","red"))
box()

tat_waiting = cbind(c(sjf.dat[1,2], sjf.dat[1,6]), c(sjf.dat[2,2], sjf.dat[2,6]), c(sjf.dat[3,2], sjf.dat[3,6]), c(sjf.dat[4,2], sjf.dat[4,6]), c(sjf.dat[5,2], sjf.dat[5,6]), c(sjf.dat[6,2], sjf.dat[6,6]), c(sjf.dat[7,2], sjf.dat[7,6]), c(sjf.dat[8,2], sjf.dat[8,6]), c(sjf.dat[9,2], sjf.dat[9,6]), c(sjf.dat[10,2], sjf.dat[10,6]), c(sjf.dat[11,2], sjf.dat[11,6]), c(sjf.dat[12,2], sjf.dat[12,6]), c(sjf.dat[13,2], sjf.dat[13,6]), c(sjf.dat[14,2], sjf.dat[14,6]), c(sjf.dat[15,2], sjf.dat[15,6]), c(sjf.dat[16,2], sjf.dat[16,6]), c(sjf.dat[17,2], sjf.dat[17,6]), c(sjf.dat[18,2], sjf.dat[18,6]), c(sjf.dat[19,2], sjf.dat[19,6]), c(sjf.dat[20,2], sjf.dat[20,6]), c(sjf.dat[21,2], sjf.dat[21,6]), c(sjf.dat[22,2], sjf.dat[22,6]), c(sjf.dat[23,2], sjf.dat[23,6]), c(sjf.dat[24,2], sjf.dat[24,6]), c(sjf.dat[25,2], sjf.dat[25,6]), c(sjf.dat[26,2], sjf.dat[26,6]), c(sjf.dat[27,2], sjf.dat[27,6]), c(sjf.dat[28,2], sjf.dat[28,6]), c(sjf.dat[29,2], sjf.dat[29,6]), c(sjf.dat[30,2], sjf.dat[30,6]), c(sjf.dat[31,2], sjf.dat[31,6]), c(sjf.dat[32,2], sjf.dat[32,6]), c(sjf.dat[33,2], sjf.dat[33,6]), c(sjf.dat[34,2], sjf.dat[34,6]), c(sjf.dat[35,2], sjf.dat[35,6]), c(sjf.dat[36,2], sjf.dat[36,6]), c(sjf.dat[37,2], sjf.dat[37,6]), c(sjf.dat[38,2], sjf.dat[38,6]), c(sjf.dat[39,2], sjf.dat[39,6]), c(sjf.dat[40,2], sjf.dat[40,6]), c(sjf.dat[41,2], sjf.dat[41,6]), c(sjf.dat[42,2], sjf.dat[42,6]), c(sjf.dat[43,2], sjf.dat[43,6]), c(sjf.dat[44,2], sjf.dat[44,6]), c(sjf.dat[45,2], sjf.dat[45,6]), c(sjf.dat[46,2], sjf.dat[46,6]), c(sjf.dat[47,2], sjf.dat[47,6]), c(sjf.dat[48,2], sjf.dat[48,6]), c(sjf.dat[49,2], sjf.dat[49,6]), c(sjf.dat[50,2], sjf.dat[50,6]))

colnames(tat_waiting) <- c(42,47,29,45,20,46,11,35,43,16,34,44,40,3,7,21,19,38,0,25,14,18,30,36,39,28,26,48,17,13,2,24,5,1,22,23,31,10,41,4,27,32,6,33,49,12,8,9,15,37)
barplot(tat_waiting, col=c("darkblue","red"),ylab="Time", beside=TRUE, main = "Arrival Time VS TAT")
legend(x=5, y=2000,c("Arrival Time", "Turnaround Time"), fill = c("darkblue","red"))
box()

#scatter plot
plot(x =arrival_time , y = bursts_time, main = "Scatter plot of tat against pid")
lines(lowess(x = arrival_time, y = bursts_time), col = "red", lwd = 1)
lowess(x = arrival_time, y = bursts_time)


#histograms
require(MASS)
#attach(sjf.dat)
hist(sjf.dat[,9], col = "grey", main = "Wait Time", ylab = "Frequency", freq = FALSE,xlab = "Time")
hist(tat, col = "grey", main = "Turn Around Time", ylab = "Frequency", freq = FALSE,xlab = "Time")
truehist(tat, nbins = "FD", col = "grey", main = "Turn Around Time", ylab = "Frequency")
truehist(sjf.dat[,9], nbins = "FD", col = "grey", main = "Wait Time", ylab = "Frequency", xlab="Time")
hist(bursts_time, col = "skyblue3", main = "Burst Time Histogram", ylab = "Density", freq = FALSE,xlab = "Burst Time")
lines(density(bursts_time), lwd = 2, col="red", lty = "dashed")
box()

#medias
sum = 0
cont = 0
sum2 = 0
cont2 = 0
s=0
s2=0
for(i in 1:50) {
  if(sjf.dat[i,7] < 1000){
    sum = sum + sjf.dat[i,3]
    s = s + sjf.dat[i,9]
    cont = cont + 1
  }
  else{
    sum2 = sum2 + sjf.dat[i,9]
    s2 = s2 + sjf.dat[i,6]
    cont2 = cont2 + 1
  }
}
m1 = s/cont
m2 = sum2/cont2
print(m1)
print(m2)


#throughput
tp = sum(sjf.dat[,5])/50
print(tp)

#grafico de barras: cpu burst
et = cat(paste(sjf.dat[,1], collapse=","))
print(et)
barplot(cpu_bursts_time, col=c("skyblue3"),ylab="Time", beside=TRUE, main = "CPU Bursts Time", 
        names.arg = c(19,32,42,3,6,0,11,13,8,43,31,5,39,24,27,33,37,22,44,14,48,34,36,25,29,4,45,49,17,20,9,10,2,12,18,40,23,28,46,16,47,1,7,15,26,30,41,35,21,38))
box()

hist(arrival_time, col = "skyblue3", main = "Arrival Time Histogram", ylab = "Density", freq = FALSE,xlab = "Time")
lines(density(arrival_time), lwd = 2, col="red", lty = "dashed")
box()

#Scatter plot matrices
pairs(cbind(cpu_bursts_time, io_bursts_time, ready_wait_time, io_wait_time), gap = 0, panel = panel.smooth)
pairs(cbind(arrival_time, cpu_bursts_time, tat, ready_wait_time), gap = 0, panel = panel.smooth)
